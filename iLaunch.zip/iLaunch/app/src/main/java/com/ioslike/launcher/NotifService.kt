package com.ioslike.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object Badges {
    @Volatile var counts: Map<String, Int> = emptyMap()
    var cb: (() -> Unit)? = null
}

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() = upd()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = upd()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = upd()
    private fun upd() {
        val m = HashMap<String, Int>()
        try {
            activeNotifications?.forEach { n ->
                if (!n.isOngoing && (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0)
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
            }
        } catch (_: Exception) {}
        Badges.counts = m
        Badges.cb?.invoke()
    }
}
