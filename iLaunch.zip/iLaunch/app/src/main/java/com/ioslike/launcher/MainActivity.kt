package com.ioslike.launcher

import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

private const val M = ViewGroup.LayoutParams.MATCH_PARENT
private const val W = ViewGroup.LayoutParams.WRAP_CONTENT

class App(val pkg: String, val label: String, val icon: Drawable, val installed: Long, val cat: Int)

class DotsView(c: Context) : View(c) {
    var n = 3; var pos = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val gap = 14 * d
        val x0 = (width - (n - 1) * gap) / 2
        for (i in 0 until n) {
            p.alpha = (255 * (1 - minOf(1f, abs(i - pos)) * 0.65f)).toInt()
            cv.drawCircle(x0 + i * gap, height / 2f, 3.5f * d, p)
        }
    }
}

class SearchIcon(c: Context) : View(c) {
    var tint = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    override fun onDraw(cv: Canvas) {
        p.color = tint; val w = width.toFloat(); p.strokeWidth = w * 0.12f
        cv.drawCircle(w * 0.42f, w * 0.42f, w * 0.33f, p)
        cv.drawLine(w * 0.66f, w * 0.66f, w * 0.92f, w * 0.92f, p)
    }
}

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var pill: FrameLayout
    private lateinit var srch: LinearLayout
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var pm: PackageManager
    private lateinit var prefs: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private var apps = listOf<App>()
    private val pages = ArrayList<View>()
    private val cells = ArrayList<View>()
    private val badgeViews = ArrayList<Pair<List<String>, TextView>>()
    private val photos = ArrayList<ImageView>()
    private var batt: TextView? = null
    private var overlay: View? = null
    private var hidden = false
    private var edit = false
    private var topIns = 0
    private var botIns = 0

    private val ctx: Context get() = this
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private val dark get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val fg get() = if (dark) Color.WHITE else Color.BLACK
    private val scrim get() = if (dark) 0x66000000 else 0x33FFFFFF
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun glass(r: Int, fill: Int = if (dark) 0x40FFFFFF else 0x55FFFFFF, stroke: Int = 0xAAFFFFFF.toInt()) =
        GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(fill); setStroke(dp(2) / 1, stroke) }
    private fun panelBg(r: Int) = glass(r, if (dark) 0xB3242428.toInt() else 0xB3FFFFFF.toInt(), 0xE6FFFFFF.toInt())

    private val toSearch = Runnable { showPill(false) }
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> { cells.forEach { it.alpha = 0f; it.scaleX = .6f; it.scaleY = .6f }; hidden = true }
                Intent.ACTION_USER_PRESENT -> if (resumed) { pop(); hidden = false }
                Intent.ACTION_BATTERY_CHANGED -> updateBattery(i)
            }
        }
    }
    private val pkgRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { load(); val cur = pager.currentItem; build(); pager.setCurrentItem(cur.coerceAtMost(pages.size - 1), false) }
    }
    private var resumed = false
    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (overlay == null && vy < -1500 && abs(vy) > abs(vx) * 1.5f && pager.currentItem in 1 until pages.size - 1) openSearch(false)
                return false
            }
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pm = packageManager; prefs = getSharedPreferences("l", 0)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = 0; window.navigationBarColor = 0
        root = FrameLayout(this); content = FrameLayout(this); root.addView(content, FrameLayout.LayoutParams(M, M))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            topIns = ins.systemWindowInsetTop; botIns = ins.systemWindowInsetBottom
            content.setPadding(0, topIns, 0, botIns); ins
        }
        pager = ViewPager2(this); pager.setClipChildren(false)
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = pages.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(
                FrameLayout(p.context).apply { layoutParams = ViewGroup.LayoutParams(M, M); setClipChildren(false) }) {}
            override fun onBindViewHolder(hd: RecyclerView.ViewHolder, i: Int) {
                val f = hd.itemView as FrameLayout; f.removeAllViews()
                (pages[i].parent as? ViewGroup)?.removeView(pages[i]); f.addView(pages[i])
            }
        }
        content.addView(pager, FrameLayout.LayoutParams(M, M))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(p: Int, o: Float, px: Int) {
                dots.pos = p + o; dots.invalidate()
                val f = ((p + o) - (pages.size - 2)).coerceIn(0f, 1f)
                dock.alpha = 1 - f; dock.translationY = f * dp(40); dock.visibility = if (f >= 1f) View.GONE else View.VISIBLE
            }
            override fun onPageScrollStateChanged(s: Int) {
                h.removeCallbacks(toSearch)
                if (s != ViewPager2.SCROLL_STATE_IDLE) showPill(true) else h.postDelayed(toSearch, 500)
            }
        })
        // pill: titik-titik saat geser, jadi "Search" saat berhenti
        pill = FrameLayout(this).apply { background = glass(18); setOnClickListener { openSearch(false) } }
        srch = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(SearchIcon(ctx), lp(dp(14), dp(14)))
            addView(TextView(ctx).apply { text = "  Search"; setTextColor(Color.WHITE); textSize = 13f })
        }
        dots = DotsView(this).apply { alpha = 0f }
        pill.addView(srch, FrameLayout.LayoutParams(W, M, Gravity.CENTER)); pill.addView(dots, FrameLayout.LayoutParams(M, M))
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; background = glass(30); setClipChildren(false) }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        stack.addView(pill, lp(dp(120), dp(34)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10) })
        stack.addView(dock, lp(M, dp(86)).apply { setMargins(dp(12), 0, dp(12), dp(8)) })
        content.addView(stack, FrameLayout.LayoutParams(M, W, Gravity.BOTTOM))

        Badges.cb = { runOnUiThread { refreshBadges() } }
        load(); build(); pager.setCurrentItem(1, false)
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_BATTERY_CHANGED) }
        val pf = IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package") }
        val st = if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgRcv, pf, Context.RECEIVER_EXPORTED); registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)
        } else { registerReceiver(pkgRcv, pf); registerReceiver(rcv, f) }
        st?.let { updateBattery(it) }
    }

    override fun onResume() {
        super.onResume(); resumed = true
        if (overlay != null) closeOverlay(false)
        if (Build.VERSION.SDK_INT >= 31) content.setRenderEffect(null)
        content.animate().cancel(); content.scaleX = 1.12f; content.scaleY = 1.12f; content.alpha = 0f
        content.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(340).setInterpolator(DecelerateInterpolator()).start()
        if (hidden) { pop(); hidden = false }
        refreshBadges(); askNotif()
    }
    override fun onPause() { super.onPause(); resumed = false }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); closeOverlay(); pager.setCurrentItem(1, true) }
    override fun onBackPressed() { if (overlay != null) closeOverlay() else pager.setCurrentItem(1, true) }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { gd.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }
    override fun onDestroy() { super.onDestroy(); Badges.cb = null; unregisterReceiver(rcv); unregisterReceiver(pkgRcv) }

    private fun askNotif() {
        val en = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        if (!en && !prefs.getBoolean("asked", false)) {
            prefs.edit().putBoolean("asked", true).apply()
            AlertDialog.Builder(this).setMessage("Aktifkan akses notifikasi supaya badge merah muncul di ikon app.")
                .setPositiveButton("Buka") { _, _ -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                .setNegativeButton("Nanti", null).show()
        }
    }

    private fun updateBattery(i: Intent) {
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        batt?.text = "${l * 100 / s}%"
    }

    // ---------- data ----------
    private fun load() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(i, 0).map { r ->
            val ai = r.activityInfo
            val t = try { pm.getPackageInfo(ai.packageName, 0).firstInstallTime } catch (e: Exception) { 0L }
            App(ai.packageName, r.loadLabel(pm).toString(), r.loadIcon(pm), t, ai.applicationInfo.category)
        }.filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
    private fun byPkg(p: String) = apps.firstOrNull { it.pkg == p }
    private fun folders(): LinkedHashMap<String, MutableList<String>> {
        val o = JSONObject(prefs.getString("f", "{}")!!); val m = LinkedHashMap<String, MutableList<String>>()
        o.keys().forEach { k -> val a = o.getJSONArray(k); m[k] = MutableList(a.length()) { a.getString(it) } }
        return m
    }
    private fun saveFolders(m: Map<String, List<String>>) {
        val o = JSONObject(); m.forEach { (k, v) -> if (v.isNotEmpty()) o.put(k, JSONArray(v)) }
        prefs.edit().putString("f", o.toString()).apply()
    }
    private fun moveTo(a: App, n: String?) {
        val m = folders(); m.values.forEach { it.remove(a.pkg) }
        if (n != null) m.getOrPut(n) { mutableListOf() }.add(a.pkg)
        saveFolders(m); val cur = pager.currentItem; build(); pager.setCurrentItem(cur.coerceAtMost(pages.size - 1), false)
    }
    private fun pickFolder(a: App) {
        val fs = folders().keys.toList(); val names = (listOf("Folder baru…") + fs).toTypedArray()
        AlertDialog.Builder(this).setItems(names) { _, i ->
            if (i == 0) {
                val e = EditText(this); e.hint = "Nama folder"
                AlertDialog.Builder(this).setView(e).setPositiveButton("OK") { _, _ ->
                    val n = e.text.toString().trim(); if (n.isNotEmpty()) moveTo(a, n)
                }.show()
            } else moveTo(a, fs[i - 1])
        }.show()
    }
    private fun catName(c: Int) = when (c) {
        ApplicationInfo.CATEGORY_SOCIAL -> "Sosial & Komunikasi"
        ApplicationInfo.CATEGORY_GAME -> "Game"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Hiburan"
        ApplicationInfo.CATEGORY_IMAGE -> "Foto & Video"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
        ApplicationInfo.CATEGORY_MAPS -> "Peta & Navigasi"
        ApplicationInfo.CATEGORY_NEWS -> "Berita"
        else -> "Lainnya"
    }

    // ---------- build ----------
    private fun build() {
        cells.clear(); badgeViews.clear(); pages.clear()
        val fs = folders(); val inF = fs.values.flatten().toSet()
        val items = ArrayList<Any>(); fs.keys.sorted().forEach { items.add(it) }
        apps.filter { it.pkg !in inF }.forEach { items.add(it) }
        pages.add(widgetPage())
        items.chunked(20).forEach { pages.add(homePage(it)) }
        if (items.isEmpty()) pages.add(homePage(items))
        pages.add(libraryPage())
        pager.adapter?.notifyDataSetChanged(); pager.offscreenPageLimit = pages.size
        dots.n = pages.size; dots.invalidate()
        dock.removeAllViews()
        val ints = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://")).addCategory(Intent.CATEGORY_BROWSABLE), Intent("android.media.action.IMAGE_CAPTURE"))
        val d = ints.mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .mapNotNull { byPkg(it) }.distinctBy { it.pkg }.toMutableList()
        apps.forEach { if (d.size < 4 && d.none { x -> x.pkg == it.pkg }) d.add(it) }
        d.take(4).forEach { dock.addView(cell(it, dp(58), false), lp(0, M, 1f)) }
        refreshBadges()
    }

    private fun homePage(items: List<Any>): View {
        val g = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(8), dp(8), 0); setClipChildren(false) }
        val w = (resources.displayMetrics.widthPixels - dp(16)) / 4
        items.forEach {
            val v = if (it is App) cell(it, dp(58)) else folderCell(it as String, dp(58))
            g.addView(v, GridLayout.LayoutParams().apply { width = w; height = dp(96) })
        }
        return FrameLayout(this).apply { setClipChildren(false); addView(g, FrameLayout.LayoutParams(M, W)) }
    }

    private fun iconView(a: App) = ImageView(this).apply {
        setImageDrawable(a.icon.constantState?.newDrawable()?.mutate() ?: a.icon)
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.225f) }
        }
    }

    private fun badge(box: FrameLayout, pkgs: List<String>) {
        val t = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(6), 0, dp(6), 0); minWidth = dp(20); minHeight = dp(20); visibility = View.GONE
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFFFF3B30.toInt()) }
        }
        box.addView(t, FrameLayout.LayoutParams(W, W, Gravity.TOP or Gravity.END).apply { setMargins(0, -dp(6), -dp(6), 0) })
        badgeViews.add(Pair(pkgs, t))
    }
    private fun refreshBadges() {
        badgeViews.forEach { (ps, t) ->
            val n = ps.sumOf { Badges.counts[it] ?: 0 }
            t.visibility = if (n > 0) View.VISIBLE else View.GONE
            t.text = if (n > 99) "99+" else n.toString()
        }
    }

    private fun cell(a: App, size: Int, label: Boolean = true, lc: Int = Color.WHITE, folder: String? = null): View {
        val box = FrameLayout(this).apply { setClipChildren(false) }
        box.addView(iconView(a), FrameLayout.LayoutParams(size, size)); badge(box, listOf(a.pkg))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6)); setClipChildren(false) }
        col.addView(box, lp(size, size))
        if (label) col.addView(TextView(this).apply {
            text = a.label; setTextColor(lc); textSize = 11f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            if (lc == Color.WHITE) setShadowLayer(4f, 0f, 1f, 0x88000000.toInt())
        }, lp(size + dp(14), W))
        col.setOnClickListener { launch(box, a.pkg) }
        col.setOnLongClickListener { menu(box, a, folder); true }
        cells.add(col); return col
    }

    private fun folderCell(name: String, size: Int): View {
        val list = (folders()[name] ?: mutableListOf<String>())
        val box = FrameLayout(this).apply { background = glass(14); setClipChildren(false) }
        val ms = (size - dp(10) - dp(6)) / 3
        val g = GridLayout(this).apply { columnCount = 3; setPadding(dp(5), dp(5), dp(5), dp(5)) }
        list.mapNotNull { byPkg(it) }.take(9).forEach {
            g.addView(iconView(it), GridLayout.LayoutParams().apply { width = ms; height = ms; setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
        box.addView(g, FrameLayout.LayoutParams(M, M)); badge(box, list)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6)); setClipChildren(false) }
        col.addView(box, lp(size, size))
        col.addView(TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, 0x88000000.toInt()) }, lp(size + dp(14), W))
        col.setOnClickListener { openFolder(name) }
        cells.add(col); return col
    }

    private fun widgetPage(): View {
        photos.clear()
        val w = (resources.displayMetrics.widthPixels - dp(32) - dp(12)) / 2
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        fun card(v: View) = FrameLayout(this).apply { background = glass(24); addView(v, FrameLayout.LayoutParams(W, W, Gravity.CENTER)) }
        val r1 = LinearLayout(this)
        batt = TextView(this).apply { text = "--%"; textSize = 40f; setTextColor(fg) }
        r1.addView(card(batt!!), lp(w, (w * 0.6f).toInt()).apply { rightMargin = dp(12) })
        r1.addView(card(TextClock(this).apply { format12Hour = "hh:mm"; format24Hour = "HH:mm"; textSize = 40f; setTextColor(fg) }), lp(w, (w * 0.6f).toInt()))
        col.addView(r1, lp(M, W).apply { bottomMargin = dp(12) })
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (c in 0..1) {
                val i = r * 2 + c
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP; background = glass(24); clipToOutline = true
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat()) }
                    }
                    File(filesDir, "p$i.jpg").takeIf { it.exists() }?.let { setImageBitmap(BitmapFactory.decodeFile(it.path)) }
                    setOnClickListener {
                        if (edit || !File(filesDir, "p$i.jpg").exists())
                            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 100 + i)
                    }
                }
                photos.add(iv); row.addView(iv, lp(w, w).apply { if (c == 0) rightMargin = dp(12) })
            }
            col.addView(row, lp(M, W).apply { bottomMargin = dp(12) })
        }
        val eb = TextView(this).apply {
            text = "Edit"; textSize = 16f; setTextColor(fg); gravity = Gravity.CENTER; background = glass(18)
            setOnClickListener {
                edit = !edit; text = if (edit) "Selesai" else "Edit"
                if (edit) Toast.makeText(ctx, "Ketuk foto untuk ganti dari galeri", Toast.LENGTH_SHORT).show()
            }
        }
        col.addView(eb, lp(dp(100), dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false; setClipChildren(false); clipToPadding = false
            setPadding(dp(16), dp(12), dp(16), dp(150)); addView(col)
        }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc !in 100..103 || res != RESULT_OK) return
        try {
            val b = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE; dec.setTargetSampleSize(maxOf(1, info.size.width / 1000))
            }
            File(filesDir, "p${rc - 100}.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            photos.getOrNull(rc - 100)?.setImageBitmap(b)
        } catch (_: Exception) {}
    }

    private fun libraryPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = glass(23); setPadding(dp(14), 0, dp(14), 0)
            addView(SearchIcon(ctx), lp(dp(16), dp(16)))
            addView(TextView(ctx).apply { text = "  App Library"; textSize = 16f; setTextColor(Color.WHITE) })
            setOnClickListener { openSearch(true) }
        }
        col.addView(bar, lp(M, dp(46)).apply { bottomMargin = dp(14) })
        val groups = LinkedHashMap<String, List<App>>()
        groups["Suggestions"] = apps.sortedByDescending { prefs.getInt("c_${it.pkg}", 0) }.take(4)
        groups["Recently Added"] = apps.sortedByDescending { it.installed }.take(4)
        apps.groupBy { catName(it.cat) }.toSortedMap().forEach { (k, v) -> groups[k] = v }
        val w = (resources.displayMetrics.widthPixels - dp(32) - dp(14)) / 2
        val keys = groups.keys.toList()
        for (r in keys.indices step 2) {
            val row = LinearLayout(this).apply { setClipChildren(false) }
            for (j in r..minOf(r + 1, keys.size - 1)) {
                val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
                val panel = FrameLayout(this).apply { background = glass(26); setClipChildren(false) }
                val cw = (w - dp(20)) / 2
                val g = GridLayout(this).apply { columnCount = 2; setPadding(dp(10), dp(10), dp(10), dp(10)); setClipChildren(false) }
                groups[keys[j]]!!.forEach { g.addView(cell(it, dp(52), false), GridLayout.LayoutParams().apply { width = cw; height = cw }) }
                panel.addView(g, FrameLayout.LayoutParams(M, M))
                t.addView(panel, lp(w, w))
                t.addView(TextView(this).apply { text = keys[j]; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, 0x88000000.toInt()) }, lp(w, W).apply { topMargin = dp(4) })
                row.addView(t, lp(w, W).apply { if (j == r) rightMargin = dp(14) })
            }
            col.addView(row, lp(M, W).apply { bottomMargin = dp(14) })
        }
        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false; setClipChildren(false); clipToPadding = false
            setPadding(dp(16), dp(12), dp(16), dp(130)); addView(col)
        }
    }

    // ---------- animasi & overlay ----------
    private fun launch(v: View, pkg: String) {
        val i = pm.getLaunchIntentForPackage(pkg) ?: return
        prefs.edit().putInt("c_$pkg", prefs.getInt("c_$pkg", 0) + 1).apply()
        try { startActivity(i, ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()) } catch (e: Exception) { return }
        if (overlay != null) closeOverlay(false)
        content.animate().cancel()
        content.animate().scaleX(1.15f).scaleY(1.15f).alpha(0f).setDuration(260).start()
    }

    private fun pop() {
        cells.forEachIndexed { i, v ->
            v.animate().cancel(); v.alpha = 0f; v.scaleX = .6f; v.scaleY = .6f; v.translationY = dp(30).toFloat()
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setStartDelay((i % 24) * 14L)
                .setDuration(420).setInterpolator(OvershootInterpolator(1.2f)).start()
        }
    }

    private fun showPill(dotsMode: Boolean) {
        srch.animate().alpha(if (dotsMode) 0f else 1f).setDuration(200).start()
        dots.animate().alpha(if (dotsMode) 1f else 0f).setDuration(200).start()
        val to = if (dotsMode) dp(14 * pages.size + 28) else dp(120)
        val l = pill.layoutParams
        ValueAnimator.ofInt(l.width, to).apply {
            duration = 250; interpolator = DecelerateInterpolator()
            addUpdateListener { l.width = it.animatedValue as Int; pill.layoutParams = l }
        }.start()
    }

    private fun blurTo(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 31) {
            ValueAnimator.ofFloat(if (on) 0f else 1f, if (on) 1f else 0f).apply {
                duration = 250
                addUpdateListener {
                    val x = it.animatedValue as Float
                    content.setRenderEffect(if (x <= 0.01f) null else RenderEffect.createBlurEffect(40f * x, 40f * x, Shader.TileMode.CLAMP))
                    try { window.setBackgroundBlurRadius((60 * x).toInt()) } catch (_: Exception) {}
                }
            }.start()
        }
        content.animate().scaleX(if (on) 0.96f else 1f).scaleY(if (on) 0.96f else 1f).setDuration(250).start()
    }

    private fun showOverlay(v: View) {
        val had = overlay != null
        overlay?.let { root.removeView(it) }
        v.alpha = 0f; root.addView(v, FrameLayout.LayoutParams(M, M)); overlay = v
        v.animate().alpha(1f).setDuration(220).start()
        if (!had) blurTo(true)
    }
    private fun closeOverlay(anim: Boolean = true) {
        val v = overlay ?: return; overlay = null
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0)
        if (anim) v.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(v) }.start() else root.removeView(v)
        blurTo(false)
    }

    private fun menu(anchor: View, a: App, folder: String?) {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val loc = IntArray(2); anchor.getLocationInWindow(loc)
        ov.addView(iconView(a), FrameLayout.LayoutParams(anchor.width, anchor.height).apply { leftMargin = loc[0]; topMargin = loc[1] })
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = panelBg(18); isClickable = true; setPadding(0, dp(6), 0, dp(6)) }
        fun item(t: String, red: Boolean, f: () -> Unit) = p.addView(TextView(this).apply {
            text = t; textSize = 16f; setTextColor(if (red) 0xFFFF3B30.toInt() else fg); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0); setOnClickListener { closeOverlay(); f() }
        }, lp(M, dp(46)))
        item("Info App", false) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) }
        if (folder == null) item("Pindah ke Folder", false) { pickFolder(a) } else item("Keluarkan dari Folder", false) { moveTo(a, null) }
        item("Hapus App", true) { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) }
        val below = loc[1] < root.height / 2
        val l = FrameLayout.LayoutParams(dp(230), W, if (below) Gravity.TOP else Gravity.BOTTOM).apply {
            leftMargin = (loc[0] + anchor.width / 2 - dp(115)).coerceIn(dp(12), maxOf(dp(12), root.width - dp(242)))
            if (below) topMargin = loc[1] + anchor.height + dp(12) else bottomMargin = root.height - loc[1] + dp(12)
        }
        ov.addView(p, l)
        p.pivotX = dp(115).toFloat(); p.pivotY = if (below) 0f else dp(200).toFloat()
        p.scaleX = .6f; p.scaleY = .6f; p.alpha = 0f
        p.animate().scaleX(1f).scaleY(1f).alpha(1f).setInterpolator(OvershootInterpolator(1.1f)).setDuration(260).start()
        showOverlay(ov)
    }

    private fun openFolder(name: String) {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(TextView(this).apply { text = name; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setShadowLayer(6f, 0f, 1f, 0x88000000.toInt()) }, lp(W, W).apply { bottomMargin = dp(12) })
        val g = GridLayout(this).apply { columnCount = 3; setClipChildren(false) }
        (folders()[name] ?: mutableListOf<String>()).mapNotNull { byPkg(it) }.forEach {
            g.addView(cell(it, dp(60), true, fg, name), GridLayout.LayoutParams().apply { width = dp(92); height = dp(100) })
        }
        val panel = FrameLayout(this).apply { background = panelBg(30); setPadding(dp(12), dp(12), dp(12), dp(12)); isClickable = true; setClipChildren(false); addView(g) }
        col.addView(panel, lp(W, W))
        ov.addView(col, FrameLayout.LayoutParams(W, W, Gravity.CENTER))
        col.scaleX = .5f; col.scaleY = .5f
        col.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(1.0f)).setDuration(300).start()
        showOverlay(ov)
    }

    private fun openSearch(list: Boolean) {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), topIns + dp(14), dp(16), botIns + dp(10)) }
        val et = EditText(this).apply {
            background = null; hint = "Search"; setHintTextColor(0x99888888.toInt()); setTextColor(fg); textSize = 17f
            maxLines = 1; inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEARCH; setPadding(dp(8), 0, 0, 0)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = panelBg(23); setPadding(dp(14), 0, dp(14), 0)
            addView(SearchIcon(ctx).apply { tint = fg }, lp(dp(18), dp(18))); addView(et, lp(0, M, 1f))
        }
        val res = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(res); isVerticalScrollBarEnabled = false }
        fun sec(t: String) = TextView(this).apply { text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg); setPadding(dp(4), dp(12), 0, dp(6)) }
        fun row(a: App): View {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
            r.addView(iconView(a), lp(dp(44), dp(44)))
            r.addView(TextView(this).apply { text = a.label; textSize = 17f; setTextColor(fg); setPadding(dp(14), 0, 0, 0) })
            r.setOnClickListener { launch(r, a.pkg) }
            return r
        }
        fun fill(q: String) {
            res.removeAllViews(); val t = q.trim().lowercase()
            if (t.isEmpty() && !list) {
                res.addView(sec("Suggestions"))
                val r = LinearLayout(this).apply { background = panelBg(26); setPadding(dp(8), dp(8), dp(8), dp(8)) }
                apps.sortedByDescending { prefs.getInt("c_${it.pkg}", 0) }.take(4).forEach { r.addView(cell(it, dp(58), true, fg), lp(0, W, 1f)) }
                res.addView(r)
            } else {
                val l = if (t.isEmpty()) apps else apps.filter { it.label.lowercase().contains(t) }
                var last = ' '
                l.forEach { a ->
                    if (t.isEmpty()) { val ch = a.label.first().uppercaseChar(); if (ch != last) { last = ch; res.addView(sec(ch.toString())) } }
                    res.addView(row(a))
                }
            }
        }
        et.doAfterTextChanged { fill(it.toString()) }
        if (list) {
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(bar, lp(0, dp(46), 1f))
            top.addView(TextView(this).apply { text = "Cancel"; textSize = 16f; setTextColor(fg); setPadding(dp(14), 0, 0, 0); setOnClickListener { closeOverlay() } })
            col.addView(top, lp(M, W)); col.addView(sv, lp(M, 0, 1f))
        } else {
            col.addView(sv, lp(M, 0, 1f)); col.addView(bar, lp(M, dp(46)).apply { topMargin = dp(8) })
        }
        fill("")
        ov.addView(col, FrameLayout.LayoutParams(M, M))
        ov.setOnClickListener { closeOverlay() }
        showOverlay(ov)
        if (!list) { et.requestFocus(); h.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0) }, 250) }
    }
}
