package com.ioslike.launcher

import android.animation.ValueAnimator
import android.app.*
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.drawToBitmap
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import kotlin.math.abs

private const val M = ViewGroup.LayoutParams.MATCH_PARENT
private const val W = ViewGroup.LayoutParams.WRAP_CONTENT
private typealias Act = Triple<String, Boolean, () -> Unit>

class App(val pkg: String, val label: String, val icon: Drawable, val installed: Long, val cat: Int, val cls: String)

/** State wallpaper blur global, dipakai semua panel kaca. */
object Wp {
    var bmp: Bitmap? = null; var dockBmp: Bitmap? = null; var src: Bitmap? = null
    var sw = 1; var sh = 1; var dark = true; var dens = 1f; var tint = 60; var dockGray = 140; var dockA = 120
}

/** Kaca blur ringan: potongan wallpaper yang sudah di-blur 1x + tint + kilau. Tanpa blur realtime = enteng. */
class Glass(private val v: View, var rad: Float, private val extra: Int = 0, private val dockMode: Boolean = false) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = Wp.dens }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2); private val m = Matrix(); private val rf = RectF()
    private var sh: BitmapShader? = null; private var shBmp: Bitmap? = null
    override fun onBoundsChange(b: Rect) {
        gloss.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.top + b.height() * 0.55f, 0x28FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }
    override fun draw(c: Canvas) {
        rf.set(bounds)
        val b = if (dockMode) (Wp.dockBmp ?: Wp.bmp) else Wp.bmp
        if (b != null) {
            if (shBmp !== b) { sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP); shBmp = b }
            v.getLocationInWindow(loc)
            m.setScale(Wp.sw.toFloat() / b.width, Wp.sh.toFloat() / b.height); m.postTranslate(-loc[0].toFloat(), -loc[1].toFloat())
            sh!!.setLocalMatrix(m); fill.shader = sh; c.drawRoundRect(rf, rad, rad, fill)
        }
        if (dockMode) { val g = Wp.dockGray; tintP.color = Color.argb(Wp.dockA, g, g, g) }
        else {
            val a = (if (b == null) 110 else Wp.tint) + extra
            tintP.color = if (Wp.dark) Color.argb(a.coerceIn(0, 255), 24, 24, 30) else Color.argb((a + 20).coerceIn(0, 255), 255, 255, 255)
        }
        c.drawRoundRect(rf, rad, rad, tintP); c.drawRoundRect(rf, rad, rad, gloss)
        edge.color = if (dockMode) 0x1AFFFFFF else 0x28FFFFFF
        rf.inset(Wp.dens / 2, Wp.dens / 2); c.drawRoundRect(rf, rad, rad, edge)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("x") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class DotsView(c: Context) : View(c) {
    var n = 3; var pos = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val gap = 14 * d; val x0 = (width - (n - 1) * gap) / 2
        for (i in 0 until n) { p.alpha = (255 * (1 - minOf(1f, abs(i - pos)) * 0.65f)).toInt(); cv.drawCircle(x0 + i * gap, height / 2f, 3.5f * d, p) }
    }
}

class SearchIcon(c: Context) : View(c) {
    var tint = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    override fun onDraw(cv: Canvas) {
        p.color = tint; val w = width.toFloat(); p.strokeWidth = w * 0.12f
        cv.drawCircle(w * 0.42f, w * 0.42f, w * 0.33f, p); cv.drawLine(w * 0.66f, w * 0.66f, w * 0.92f, w * 0.92f, p)
    }
}

class ClockView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable { override fun run() { if (isShown) invalidate(); postDelayed(this, 1000) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) * 0.42f
        p.style = Paint.Style.FILL; p.color = Color.WHITE; cv.drawCircle(cx, cy, r, p)
        val t = Calendar.getInstance(); val s = t.get(Calendar.SECOND).toFloat()
        val m = t.get(Calendar.MINUTE) + s / 60f; val h = t.get(Calendar.HOUR) + m / 60f
        p.color = Color.BLACK; p.textSize = r * 0.28f; p.textAlign = Paint.Align.CENTER; val o = p.textSize / 3
        cv.drawText("12", cx, cy - r * 0.72f + o, p); cv.drawText("6", cx, cy + r * 0.72f + o, p)
        cv.drawText("3", cx + r * 0.74f, cy + o, p); cv.drawText("9", cx - r * 0.74f, cy + o, p)
        fun hand(deg: Float, len: Float, wd: Float, col: Int) {
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.color = col; p.strokeWidth = wd
            cv.save(); cv.rotate(deg, cx, cy); cv.drawLine(cx, cy, cx, cy - len, p); cv.restore()
        }
        hand(h * 30f, r * 0.5f, r * 0.06f, Color.BLACK); hand(m * 6f, r * 0.75f, r * 0.045f, Color.BLACK); hand(s * 6f, r * 0.82f, r * 0.03f, 0xFFFF9500.toInt())
        p.style = Paint.Style.FILL; p.color = 0xFFFF9500.toInt(); cv.drawCircle(cx, cy, r * 0.05f, p)
    }
}

class RingView(c: Context) : View(c) {
    var pct = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val sz = height * 0.42f; val pad = 14 * d
        p.style = Paint.Style.STROKE; p.strokeWidth = 5 * d; p.strokeCap = Paint.Cap.ROUND
        val rf = RectF(pad, pad, pad + sz, pad + sz)
        p.color = 0x44FFFFFF; cv.drawArc(rf, 0f, 360f, false, p)
        p.color = 0xFF30D158.toInt(); cv.drawArc(rf, -90f, 360f * pct / 100f, false, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = height * 0.2f; p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText("$pct%", pad, height - pad, p)
    }
}

class MainActivity : Activity() {
    private class Fold(var name: String, val apps: MutableList<String>)
    private class Place(val e: String, val idx: Int, val r: Int, val c: Int, val sr: Int, val sc: Int)

    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var wallView: ImageView
    private lateinit var pager: ViewPager2
    private lateinit var pill: FrameLayout
    private lateinit var srch: LinearLayout
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var pm: PackageManager
    private lateinit var prefs: SharedPreferences
    private lateinit var awm: AppWidgetManager
    private lateinit var host: AppWidgetHost
    private val h = Handler(Looper.getMainLooper())
    private var apps = listOf<App>()
    private val pages = ArrayList<View>()
    private val cells = ArrayList<View>()
    private val glassList = ArrayList<View>()
    private val homeViews = HashMap<Int, View>()
    private val widgetViews = ArrayList<Pair<String, View>>()
    private var layoutPlaces: List<List<Place>> = emptyList()
    private var lastBatt = 0
    private var packIndex: Map<String, File>? = null
    private val badgeViews = ArrayList<Pair<List<String>, TextView>>()
    private val photos = ArrayList<ImageView>()
    private val icCache = HashMap<String, Bitmap>()
    private val home = ArrayList<String>()
    private val folds = LinkedHashMap<String, Fold>()
    private var ring: RingView? = null
    private var overlay: View? = null
    private var ovBlur = false
    private var blurAnim: ValueAnimator? = null
    private var blurLvl = 0f
    private var hidden = false; private var resumed = false; private var edit = false
    private var topIns = 0; private var botIns = 0
    private var pendingWid = -1
    // drag
    private var armEntry: String? = null; private var armView: View? = null; private var armCtx = 0
    private var armX = 0f; private var armY = 0f; private var lastX = 0f; private var lastY = 0f
    private var dragView: ImageView? = null; private var dragging = false; private var srcCell: View? = null
    private var tgtView: View? = null; private var mergeIdx = -1; private var edgeDir = 0
    private var openFid: String? = null; private var folderGrid: GridLayout? = null; private var folderPanel: View? = null

    private val ctx: Context get() = this
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private val dark get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val fg get() = if (dark) Color.WHITE else Color.BLACK
    private val scrim get() = if (dark) 0x55000000 else 0x33FFFFFF
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private val cols get() = prefs.getInt("cols", 4)
    private val rows get() = prefs.getInt("rows", 6)
    private val cap get() = cols * rows
    private val iconSz get() = dp(58) * prefs.getInt("scale", 100) / 100
    private val labels get() = prefs.getBoolean("labels", true)
    private val cellH get() = iconSz + dp(14) + (if (labels) dp(20) else 0)
    private val cellW get() = (resources.displayMetrics.widthPixels - dp(16)) / cols

    private fun glassOn(v: View, r: Int, extra: Int = 0): View { v.background = Glass(v, dp(r).toFloat(), extra); glassList.add(v); return v }

    private val toSearch = Runnable { showPill(false) }
    private val edgeRun = object : Runnable {
        override fun run() {
            val t = pager.currentItem + edgeDir
            if (dragging && edgeDir != 0) { if (t in 1..pages.size - 2) pager.setCurrentItem(t, true); h.postDelayed(this, 900) }
        }
    }
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> { cells.forEach { it.alpha = 0f; it.scaleX = .6f; it.scaleY = .6f }; hidden = true }
                Intent.ACTION_USER_PRESENT -> if (resumed) { pop(); hidden = false }
                Intent.ACTION_BATTERY_CHANGED -> updateBattery(i)
            }
        }
    }
    private val pkgRcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { load(); normalize(); saveLayout(); rebuildKeep() }
    }
    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (overlay == null && vy < -1500 && abs(vy) > abs(vx) * 1.5f && pager.currentItem in 1 until pages.size - 1) openSearch(false)
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                if (overlay != null || dragging) return
                val wv = hitWidget(e.rawX, e.rawY)
                if (wv != null) { widgetMenu(wv.first, wv.second); return }
                if (hitCell(e.rawX, e.rawY) == null) showEditBar()
            }
        })
    }

    // ================= lifecycle =================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pm = packageManager; prefs = getSharedPreferences("l", 0)
        awm = AppWidgetManager.getInstance(this); host = AppWidgetHost(this, 1024)
        Wp.dens = resources.displayMetrics.density; Wp.dark = dark
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = 0; window.navigationBarColor = 0
        root = FrameLayout(this); stage = FrameLayout(this); content = FrameLayout(this)
        wallView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        stage.addView(wallView, M, M); stage.addView(content, M, M); root.addView(stage, M, M); setContentView(root)
        root.setOnApplyWindowInsetsListener { _, ins ->
            topIns = ins.systemWindowInsetTop; botIns = ins.systemWindowInsetBottom; content.setPadding(0, topIns, 0, botIns); ins
        }
        pager = ViewPager2(this); pager.setClipChildren(false)
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = pages.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(
                FrameLayout(p.context).apply { layoutParams = ViewGroup.LayoutParams(M, M); setClipChildren(false) }) {}
            override fun onBindViewHolder(hd: RecyclerView.ViewHolder, i: Int) {
                val f = hd.itemView as FrameLayout; f.removeAllViews()
                (pages[i].parent as? ViewGroup)?.removeView(pages[i]); f.addView(pages[i])
            }
        }
        content.addView(pager, FrameLayout.LayoutParams(M, M))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(p: Int, o: Float, px: Int) {
                val t = p + o; val last = (pages.size - 1).toFloat()
                dots.pos = t; dots.invalidate()
                val a = minOf(t, 1f, last - t).coerceIn(0f, 1f)          // pill hilang di halaman paling kiri & kanan
                pill.alpha = a; pill.visibility = if (a <= 0.02f) View.INVISIBLE else View.VISIBLE
                val f = maxOf((t - (last - 1)).coerceIn(0f, 1f), (1f - t).coerceIn(0f, 1f))   // dock hilang di halaman kiri & App Library
                dock.alpha = 1 - f; dock.translationY = f * dp(40)
                dock.visibility = if (f >= 1f || prefs.getBoolean("nodock", false)) View.GONE else View.VISIBLE
            }
            override fun onPageScrollStateChanged(s: Int) {
                h.removeCallbacks(toSearch)
                if (s != ViewPager2.SCROLL_STATE_IDLE) showPill(true) else { h.postDelayed(toSearch, 500); glassList.forEach { it.invalidate() } }
            }
        })
        pill = FrameLayout(this).apply { setOnClickListener { openSearch(false) } }
        glassOn(pill, 18)
        srch = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(SearchIcon(ctx), lp(dp(14), dp(14)))
            addView(TextView(ctx).apply { text = "  Search"; setTextColor(Color.WHITE); textSize = 13f })
        }
        dots = DotsView(this).apply { alpha = 0f }
        pill.addView(srch, FrameLayout.LayoutParams(W, M, Gravity.CENTER)); pill.addView(dots, FrameLayout.LayoutParams(M, M))
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; setClipChildren(false) }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        stack.addView(pill, lp(dp(120), dp(34)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10) })
        stack.addView(dock, lp(M, dp(86)).apply { setMargins(dp(12), 0, dp(12), dp(8)) })
        content.addView(stack, FrameLayout.LayoutParams(M, W, Gravity.BOTTOM))
        Badges.cb = { runOnUiThread { refreshBadges() } }
        Wp.tint = 36 + prefs.getInt("blur", 60) * 3 / 10
        load(); loadLayout(); migrateWidgets(); loadWall(); build(); pager.setCurrentItem(1, false)
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_BATTERY_CHANGED) }
        val pf = IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package") }
        registerReceiver(pkgRcv, pf, Context.RECEIVER_EXPORTED)
        registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)?.let { updateBattery(it) }
    }
    override fun onStart() { super.onStart(); try { host.startListening() } catch (_: Exception) {} }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (_: Exception) {} }
    override fun onResume() {
        super.onResume(); resumed = true
        if (overlay != null) closeOverlay(false)
        stage.setRenderEffect(null); blurLvl = 0f
        content.animate().cancel(); content.scaleX = 1.12f; content.scaleY = 1.12f; content.alpha = 0f
        content.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(340).setInterpolator(DecelerateInterpolator()).start()
        if (hidden) { pop(); hidden = false }
        refreshBadges(); askNotif()
    }
    override fun onPause() { super.onPause(); resumed = false }
    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); closeOverlay(); pager.setCurrentItem(1, true) }
    override fun onBackPressed() { if (overlay != null) closeOverlay() else pager.setCurrentItem(1, true) }
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); applyAll(false) }
    override fun onDestroy() { super.onDestroy(); Badges.cb = null; unregisterReceiver(rcv); unregisterReceiver(pkgRcv) }

    private fun askNotif() {
        val en = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        if (!en && !prefs.getBoolean("asked", false)) {
            prefs.edit().putBoolean("asked", true).apply()
            AlertDialog.Builder(this).setMessage("Aktifkan akses notifikasi supaya badge merah muncul di ikon app.")
                .setPositiveButton("Buka") { _, _ -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                .setNegativeButton("Nanti", null).show()
        }
    }
    private fun updateBattery(i: Intent) {
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        lastBatt = l * 100 / sc
        ring?.let { it.pct = lastBatt; it.invalidate() }
    }

    // ================= data =================
    private fun load() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(i, 0).map { r ->
            val ai = r.activityInfo
            val t = try { pm.getPackageInfo(ai.packageName, 0).firstInstallTime } catch (e: Exception) { 0L }
            App(ai.packageName, r.loadLabel(pm).toString(), r.loadIcon(pm), t, ai.applicationInfo.category, ai.name)
        }.filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
    private fun byPkg(p: String) = apps.firstOrNull { it.pkg == p }
    private fun onHome(p: String) = home.contains(p) || folds.values.any { p in it.apps }

    private fun saveLayout() {
        val o = JSONObject(); o.put("home", JSONArray(home))
        val f = JSONObject(); folds.forEach { (k, v) -> f.put(k, JSONObject().put("n", v.name).put("a", JSONArray(v.apps))) }
        o.put("folds", f); prefs.edit().putString("layout", o.toString()).apply()
    }
    private fun loadLayout() {
        home.clear(); folds.clear()
        val s = prefs.getString("layout", null)
        if (s == null) { apps.take(cap + cap / 2).forEach { home.add(it.pkg) }; saveLayout(); return }
        val o = JSONObject(s); val a = o.getJSONArray("home"); for (i in 0 until a.length()) home.add(a.getString(i))
        val f = o.getJSONObject("folds")
        f.keys().forEach { k -> val j = f.getJSONObject(k); val aa = j.getJSONArray("a"); folds[k] = Fold(j.getString("n"), MutableList(aa.length()) { aa.getString(it) }) }
        normalize()
    }
    private fun normalize() {
        val ok = apps.map { it.pkg }.toSet()
        folds.values.forEach { it.apps.retainAll(ok) }
        home.removeAll { !it.startsWith("#") && !it.startsWith("w:") && it !in ok }
        home.removeAll { it.startsWith("w:") && awm.getAppWidgetInfo(it.drop(2).toIntOrNull() ?: -1) == null }
        val iter = folds.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next(); val id = "#" + e.key
            if (e.value.apps.size <= 1) {
                val i = home.indexOf(id)
                if (i >= 0) { if (e.value.apps.size == 1) home[i] = e.value.apps[0] else home.removeAt(i) }
                iter.remove()
            }
        }
        home.removeAll { it.startsWith("#") && !folds.containsKey(it.drop(1)) }
    }
    private fun rebuildKeep() { val c = pager.currentItem; build(); pager.setCurrentItem(c.coerceIn(0, pages.size - 1), false) }
    private fun removeFromHome(p: String) { home.remove(p); folds.values.forEach { it.apps.remove(p) }; normalize(); saveLayout(); rebuildKeep() }
    private fun addToHome(p: String) {
        val t = ArrayList(home); t.add(p)
        if (paginate(t).size > 2) { toast("Home penuh (2 halaman). Hapus satu dulu."); return }
        home.add(p); saveLayout(); rebuildKeep(); toast("Ditambahkan ke Home")
    }
    private fun migrateWidgets() {
        val w = prefs.getString("wids", "") ?: ""; if (w.isEmpty()) return
        w.split(",").mapNotNull { it.toIntOrNull() }.forEach { if (awm.getAppWidgetInfo(it) != null) home.add("w:$it") }
        prefs.edit().remove("wids").apply(); saveLayout()
    }
    private fun catName(c: Int) = when (c) {
        ApplicationInfo.CATEGORY_SOCIAL -> "Sosial & Komunikasi"
        ApplicationInfo.CATEGORY_GAME -> "Game"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Hiburan"
        ApplicationInfo.CATEGORY_IMAGE -> "Foto & Video"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
        ApplicationInfo.CATEGORY_MAPS -> "Peta & Navigasi"
        ApplicationInfo.CATEGORY_NEWS -> "Berita"
        else -> "Lainnya"
    }

    // ================= wallpaper & ikon =================
    private fun loadWall() {
        val bd = windowManager.maximumWindowMetrics.bounds; val sw = bd.width(); val sh = bd.height()
        Wp.sw = sw; Wp.sh = sh
        var src: Bitmap? = null
        val f = File(filesDir, "wall.jpg")
        if (f.exists()) src = BitmapFactory.decodeFile(f.path)
        if (src == null) try { src = WallpaperManager.getInstance(this).drawable?.toBitmap() } catch (_: Exception) {}
        if (src == null) { Wp.bmp = null; Wp.dockBmp = null; Wp.src = null; wallView.setImageDrawable(null); return }
        val sc = maxOf(sw.toFloat() / src.width, sh.toFloat() / src.height)
        val scr = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val mt = Matrix().apply { setScale(sc, sc); postTranslate((sw - src.width * sc) / 2, (sh - src.height * sc) / 2) }
        Canvas(scr).drawBitmap(src, mt, Paint(Paint.FILTER_BITMAP_FLAG))
        wallView.setImageBitmap(scr); Wp.src = scr
        val f1 = 4 + prefs.getInt("blur", 60) / 5f
        val s1 = Bitmap.createScaledBitmap(scr, sw / 4, sh / 4, true)
        Wp.bmp = Bitmap.createScaledBitmap(s1, (sw / f1).toInt().coerceAtLeast(8), (sh / f1).toInt().coerceAtLeast(8), true)
        recalcDockBlur()
    }
    private fun applyAll(wall: Boolean) {
        icCache.clear(); Wp.dark = dark; Wp.tint = 36 + prefs.getInt("blur", 60) * 3 / 10
        if (wall) loadWall()
        rebuildKeep()
    }
    private fun icon(a: App): Bitmap = icCache.getOrPut(a.pkg + prefs.getInt("style", 0) + dark) { renderIcon(a) }

    private val genericPkg = mapOf(
        "com.android.chrome" to "chrome", "com.android.vending" to "playstore", "com.google.android.apps.messaging" to "messages",
        "com.google.android.dialer" to "phone", "com.android.dialer" to "phone", "com.android.settings" to "settings",
        "com.google.android.apps.maps" to "googlemaps", "com.google.android.gm" to "gmail", "com.google.android.googlequicksearchbox" to "googlesearch",
        "com.google.android.apps.photos" to "googlephotos", "com.google.android.youtube" to "youtube", "com.google.android.apps.youtube.music" to "ytmusic",
        "com.whatsapp" to "whatsapp", "com.instagram.android" to "instagram", "com.facebook.katana" to "facebook", "com.pinterest" to "pinterest",
        "com.google.android.apps.docs" to "googledrive", "com.google.android.apps.bard" to "gemini", "com.transsion.phonemaster" to "phonemaster",
        "com.android.camera" to "camera", "com.mediatek.camera" to "camera", "com.android.contacts" to "contacts", "com.google.android.contacts" to "contacts",
        "com.android.calculator2" to "calculator", "com.google.android.calculator" to "calculator", "com.android.deskclock" to "clock", "com.google.android.deskclock" to "clock")

    private fun pack(): Map<String, File> {
        packIndex?.let { return it }
        val m = HashMap<String, File>()
        File(filesDir, "iconpack").listFiles()?.forEach { f -> var n = f.name.lowercase(); while (n.endsWith(".png")) n = n.dropLast(4); m[n] = f }
        packIndex = m; return m
    }
    private fun packIcon(a: App): Bitmap? {
        val m = pack(); if (m.isEmpty()) return null
        val k1 = (if (a.cls.startsWith(".")) a.pkg + a.cls else a.cls).replace('.', '_').lowercase()
        var f: File? = m[k1]
        if (f == null) { val pre = a.pkg.replace('.', '_').lowercase() + "_"; f = m.entries.firstOrNull { it.key.startsWith(pre) }?.value }
        if (f == null) f = genericPkg[a.pkg]?.let { m[it] }
        if (f == null) {
            val toks = a.pkg.lowercase().split('.', '_'); val lab = a.label.lowercase().replace(" ", "")
            f = m.entries.firstOrNull { e -> !e.key.contains('_') && e.key.length >= 4 && (lab == e.key || toks.any { t -> t == e.key || (t.startsWith(e.key) && t.length <= e.key.length + 2) }) }?.value
        }
        return f?.let { fl -> BitmapFactory.decodeFile(fl.path)?.let { b -> Bitmap.createScaledBitmap(b, 144, 144, true) } }
    }
    private fun themedWrap(src: Bitmap, s: Int): Bitmap {
        val m = pack()
        val mask = m["icon_mask"]?.let { BitmapFactory.decodeFile(it.path) }
        val top = m["icon_top"]?.let { BitmapFactory.decodeFile(it.path) }
        if (mask == null && top == null) return src
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888); val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(src, 0f, 0f, p)
        if (mask != null) { p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN); c.drawBitmap(Bitmap.createScaledBitmap(mask, s, s, true), 0f, 0f, p); p.xfermode = null }
        if (top != null) c.drawBitmap(Bitmap.createScaledBitmap(top, s, s, true), 0f, 0f, p)
        return out
    }
    private fun renderIcon(a: App): Bitmap {
        if (prefs.getInt("style", 0) == 2) { packIcon(a)?.let { return it }; return themedWrap(baseIcon(a, 144), 144) }
        return baseIcon(a, 144)
    }
    private fun baseIcon(a: App, s: Int): Bitmap {
        val bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888); val c = Canvas(bm)
        val rr = s * 0.225f
        c.clipPath(Path().apply { addRoundRect(0f, 0f, s.toFloat(), s.toFloat(), rr, rr, Path.Direction.CW) })
        val d = a.icon; val themed = prefs.getInt("style", 0) == 1
        fun layer(l: Drawable) { val o = (s * 0.25f).toInt(); l.setBounds(-o, -o, s + o, s + o); l.draw(c) }
        val plate = if (dark) 0xFF2C2C2E.toInt() else 0xFFE9E9EF.toInt()
        if (d is AdaptiveIconDrawable) {
            val mono = if (themed && Build.VERSION.SDK_INT >= 33) d.monochrome else null
            if (mono != null) { c.drawColor(plate); mono.mutate().setTint(if (dark) 0xFFEDEDF2.toInt() else 0xFF2B2B33.toInt()); layer(mono) }
            else { d.background?.let { layer(it) }; d.foreground?.let { layer(it) } }
        } else {
            c.drawColor(if (themed) plate else 0xFFEFEFF4.toInt()); val i = (s * 0.12f).toInt(); d.setBounds(i, i, s - i, s - i); d.draw(c)
        }
        return bm
    }
    private fun iconView(a: App) = ImageView(this).apply { setImageBitmap(icon(a)); scaleType = ImageView.ScaleType.FIT_XY }

    // ================= build =================
    private fun build() {
        cells.clear(); badgeViews.clear(); glassList.clear(); homeViews.clear(); widgetViews.clear(); pages.clear()
        glassOn(pill, 18); glassList.add(dock)
        layoutPlaces = paginate(home)
        pages.add(widgetPage())
        for (p in 0 until maxOf(2, layoutPlaces.size)) pages.add(homePage(layoutPlaces.getOrElse(p) { emptyList() }))
        pages.add(libraryPage())
        pager.adapter?.notifyDataSetChanged(); pager.offscreenPageLimit = 1
        dots.n = pages.size; dots.invalidate()
        buildDock(); applyDock()
    }

    private fun buildDock() {
        dock.removeAllViews()
        val ints = listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://")).addCategory(Intent.CATEGORY_BROWSABLE), Intent("android.media.action.IMAGE_CAPTURE"))
        val d = ints.mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .mapNotNull { byPkg(it) }.distinctBy { it.pkg }.toMutableList()
        apps.forEach { if (d.size < 4 && d.none { x -> x.pkg == it.pkg }) d.add(it) }
        d.take(4).forEach { dock.addView(cell(it, dp(prefs.getInt("dk_i", 58)), false), lp(0, M, 1f)) }
        refreshBadges()
    }
    private fun recalcDockBlur() {
        val s = Wp.src ?: return
        val f1 = 4 + prefs.getInt("dk_blur", 60) / 5f
        val s1 = Bitmap.createScaledBitmap(s, Wp.sw / 4, Wp.sh / 4, true)
        Wp.dockBmp = Bitmap.createScaledBitmap(s1, (Wp.sw / f1).toInt().coerceAtLeast(8), (Wp.sh / f1).toInt().coerceAtLeast(8), true)
    }
    private fun applyDock() {
        Wp.dockGray = (prefs.getInt("dk_br", if (dark) 55 else 80) * 255 / 100).coerceIn(0, 255)
        Wp.dockA = prefs.getInt("dk_a", 120)
        val rad = dp(prefs.getInt("dk_r", 30)).toFloat()
        val g = dock.background as? Glass
        if (g != null) g.rad = rad else dock.background = Glass(dock, rad, 0, true)
        val l = dock.layoutParams as LinearLayout.LayoutParams
        val m = dp(prefs.getInt("dk_m", 12)); l.height = dp(prefs.getInt("dk_h", 86)); l.setMargins(m, 0, m, dp(prefs.getInt("dk_y", 8)))
        dock.layoutParams = l; dock.invalidate()
        dock.visibility = if (prefs.getBoolean("nodock", false)) View.GONE else View.VISIBLE
    }

    private fun spanInfo(info: AppWidgetProviderInfo): Pair<Int, Int> {
        val sc = Math.ceil(info.minWidth.toDouble() / cellW).toInt().coerceIn(1, cols)
        val sr = Math.ceil(info.minHeight.toDouble() / cellH).toInt().coerceIn(1, rows)
        return Pair(sr, sc)
    }
    private fun spanOf(e: String): Pair<Int, Int> {
        if (!e.startsWith("w:")) return Pair(1, 1)
        val info = awm.getAppWidgetInfo(e.drop(2).toIntOrNull() ?: -1) ?: return Pair(2, 2)
        return spanInfo(info)
    }
    private fun paginate(list: List<String>): List<List<Place>> {
        val out = ArrayList<ArrayList<Place>>(); var occ = Array(rows) { BooleanArray(cols) }; var cur = ArrayList<Place>()
        list.forEachIndexed { i, e ->
            val (sr, sc) = spanOf(e)
            fun find(): Pair<Int, Int>? {
                for (r in 0..rows - sr) for (c in 0..cols - sc) {
                    var ok = true
                    loop@ for (a in r until r + sr) for (b in c until c + sc) if (occ[a][b]) { ok = false; break@loop }
                    if (ok) return Pair(r, c)
                }
                return null
            }
            var pos = find()
            if (pos == null) { out.add(cur); cur = ArrayList(); occ = Array(rows) { BooleanArray(cols) }; pos = find() ?: Pair(0, 0) }
            for (a in pos.first until pos.first + sr) for (b in pos.second until pos.second + sc) occ[a][b] = true
            cur.add(Place(e, i, pos.first, pos.second, sr, sc))
        }
        if (cur.isNotEmpty() || out.isEmpty()) out.add(cur)
        return out
    }

    private fun homePage(places: List<Place>): View {
        val f = FrameLayout(this).apply { setClipChildren(false) }
        places.forEach { p ->
            val e = p.e
            val v: View? = when {
                e.startsWith("#") -> folderCell(e.drop(1))
                e.startsWith("w:") -> widgetView(e, p)
                else -> byPkg(e)?.let { cell(it, iconSz, labels, Color.WHITE, null, true) }
            }
            if (v != null) {
                f.addView(v, FrameLayout.LayoutParams(p.sc * cellW, p.sr * cellH).apply { leftMargin = dp(8) + p.c * cellW; topMargin = dp(8) + p.r * cellH })
                homeViews[p.idx] = v
            }
        }
        return f
    }
    private fun widgetView(e: String, p: Place): View? {
        val id = e.drop(2).toIntOrNull() ?: return null; val info = awm.getAppWidgetInfo(id) ?: return null
        return try {
            val hv = host.createView(this, id, info); val den = resources.displayMetrics.density
            val w = ((p.sc * cellW - dp(8)) / den).toInt(); val hh = ((p.sr * cellH - dp(8)) / den).toInt()
            hv.updateAppWidgetSize(null, w, hh, w, hh)
            val box = FrameLayout(this).apply { setPadding(dp(4), dp(4), dp(4), dp(4)); addView(hv, FrameLayout.LayoutParams(M, M)) }
            widgetViews.add(Pair(e, box)); box
        } catch (_: Exception) { null }
    }
    private fun hitWidget(x: Float, y: Float): Pair<String, View>? {
        val r = Rect()
        for (p in widgetViews) if (p.second.isShown && p.second.getGlobalVisibleRect(r) && r.contains(x.toInt(), y.toInt())) return p
        return null
    }
    private fun widgetMenu(e: String, v: View) { menu(v, e, true, listOf<Act>(Triple("Hapus Widget", true, { removeWidget(e) }))) }
    private fun removeWidget(e: String) {
        home.remove(e); try { host.deleteAppWidgetId(e.drop(2).toInt()) } catch (_: Exception) {}
        saveLayout(); rebuildKeep()
    }

    private fun badge(box: FrameLayout, pkgs: List<String>) {
        val t = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(6), 0, dp(6), 0); minWidth = dp(20); minHeight = dp(20); visibility = View.GONE
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFFFF3B30.toInt()) }
        }
        box.addView(t, FrameLayout.LayoutParams(W, W, Gravity.TOP or Gravity.END).apply { setMargins(0, -dp(6), -dp(6), 0) })
        badgeViews.add(Pair(pkgs, t))
    }
    private fun refreshBadges() {
        badgeViews.forEach { (ps, t) ->
            val n = ps.sumOf { Badges.counts[it] ?: 0 }
            t.visibility = if (n > 0) View.VISIBLE else View.GONE; t.text = if (n > 99) "99+" else n.toString()
        }
    }

    private fun cell(a: App, size: Int, label: Boolean = true, lc: Int = Color.WHITE, folder: String? = null, onHomeGrid: Boolean = false): View {
        val box = FrameLayout(this).apply { setClipChildren(false) }
        box.addView(iconView(a), FrameLayout.LayoutParams(size, size)); badge(box, listOf(a.pkg))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6)); setClipChildren(false) }
        col.addView(box, lp(size, size))
        if (label) col.addView(TextView(this).apply {
            text = a.label; setTextColor(lc); textSize = 11f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            if (lc == Color.WHITE) setShadowLayer(3f, 0f, 1f, 0x99000000.toInt())
        }, lp(size + dp(14), W))
        col.setOnClickListener { launch(box, a.pkg) }
        col.setOnLongClickListener { if (folder != null) arm(a.pkg, box, 2) else menu(box, a.pkg, onHomeGrid, appItems(a.pkg)); true }
        cells.add(col); return col
    }

    private fun folderCell(fid: String): View {
        val f = folds[fid]!!; val size = iconSz
        val box = FrameLayout(this).apply { setClipChildren(false) }; glassOn(box, 16)
        val ms = (size - dp(10) - dp(6)) / 3
        val g = GridLayout(this).apply { columnCount = 3; setPadding(dp(5), dp(5), dp(5), dp(5)) }
        f.apps.mapNotNull { byPkg(it) }.take(9).forEach {
            g.addView(iconView(it), GridLayout.LayoutParams().apply { width = ms; height = ms; setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
        box.addView(g, FrameLayout.LayoutParams(M, M)); badge(box, f.apps)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(6), 0, dp(6)); setClipChildren(false) }
        col.addView(box, lp(size, size))
        if (labels) col.addView(TextView(this).apply { text = f.name; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1; gravity = Gravity.CENTER; setShadowLayer(3f, 0f, 1f, 0x99000000.toInt()) }, lp(size + dp(14), W))
        col.setOnClickListener { openFolder(fid) }
        col.setOnLongClickListener {
            menu(box, "#$fid", true, listOf<Act>(
                Triple("Ganti Nama", false, { renameFolder(fid) }),
                Triple("Bubarkan Folder", true, { val i = home.indexOf("#$fid"); folds.remove(fid)?.let { x -> home.removeAt(i); home.addAll(i, x.apps) }; saveLayout(); rebuildKeep() })))
            true
        }
        cells.add(col); return col
    }
    private fun renameFolder(fid: String) {
        val f = folds[fid] ?: return; val e = EditText(this); e.setText(f.name)
        AlertDialog.Builder(this).setTitle("Nama folder").setView(e).setPositiveButton("OK") { _, _ ->
            val n = e.text.toString().trim(); if (n.isNotEmpty()) { f.name = n; saveLayout(); rebuildKeep(); if (openFid == fid) openFolder(fid) }
        }.show()
    }

    // ================= halaman widget =================
    private fun widgetPage(): View {
        photos.clear()
        val w = (resources.displayMetrics.widthPixels - dp(32) - dp(12)) / 2
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        val r1 = LinearLayout(this).apply { setClipChildren(false) }
        val rv = RingView(this).also { ring = it; it.pct = lastBatt }
        val bc = FrameLayout(this).apply { addView(rv, FrameLayout.LayoutParams(M, M)) }; glassOn(bc, 26)
        val cc = FrameLayout(this).apply { setBackgroundColor(0); addView(ClockView(ctx), FrameLayout.LayoutParams(M, M)) }
        cc.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(0xFF1C1C1E.toInt()) }
        r1.addView(bc, lp(w, w).apply { rightMargin = dp(12) }); r1.addView(cc, lp(w, w))
        col.addView(r1, lp(M, W).apply { bottomMargin = dp(14) })
        for (r in 0..1) {
            val row = LinearLayout(this).apply { setClipChildren(false) }
            for (c in 0..1) {
                val i = r * 2 + c
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true; elevation = dp(10).toFloat()
                    background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(0x33FFFFFF) }
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(22).toFloat()) }
                    }
                    File(filesDir, "p$i.jpg").takeIf { it.exists() }?.let { setPhoto(this, BitmapFactory.decodeFile(it.path)) }
                    setOnClickListener {
                        if (edit || !File(filesDir, "p$i.jpg").exists()) startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 100 + i)
                    }
                }
                photos.add(iv); row.addView(iv, lp(w, w).apply { if (c == 0) rightMargin = dp(12) })
            }
            col.addView(row, lp(M, W).apply { bottomMargin = dp(14) })
        }
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; setClipChildren(false); clipToPadding = false; setPadding(dp(16), dp(12), dp(16), dp(150)); addView(col) }
    }

    // ================= App Library =================
    private fun libraryPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), 0)
            addView(SearchIcon(ctx), lp(dp(16), dp(16))); addView(TextView(ctx).apply { text = "  App Library"; textSize = 16f; setTextColor(Color.WHITE) })
            setOnClickListener { openSearch(true) }
        }
        glassOn(bar, 23); col.addView(bar, lp(M, dp(46)).apply { bottomMargin = dp(14) })
        val groups = LinkedHashMap<String, List<App>>()
        groups["Suggestions"] = apps.sortedByDescending { prefs.getInt("c_${it.pkg}", 0) }.take(4)
        groups["Recently Added"] = apps.sortedByDescending { it.installed }.take(4)
        apps.groupBy { catName(it.cat) }.toSortedMap().forEach { (k, v) -> groups[k] = v }
        val w = (resources.displayMetrics.widthPixels - dp(32) - dp(14)) / 2
        val keys = groups.keys.toList()
        for (r in keys.indices step 2) {
            val row = LinearLayout(this).apply { setClipChildren(false) }
            for (j in r..minOf(r + 1, keys.size - 1)) {
                val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setClipChildren(false) }
                val panel = FrameLayout(this).apply { setClipChildren(false) }; glassOn(panel, 26)
                val cw = (w - dp(20)) / 2
                val g = GridLayout(this).apply { columnCount = 2; setPadding(dp(10), dp(10), dp(10), dp(10)); setClipChildren(false) }
                groups[keys[j]]!!.forEach { g.addView(cell(it, dp(52), false), GridLayout.LayoutParams().apply { width = cw; height = cw }) }
                panel.addView(g, FrameLayout.LayoutParams(M, M)); t.addView(panel, lp(w, w))
                t.addView(TextView(this).apply { text = keys[j]; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setShadowLayer(3f, 0f, 1f, 0x99000000.toInt()) }, lp(w, W).apply { topMargin = dp(4) })
                row.addView(t, lp(w, W).apply { if (j == r) rightMargin = dp(14) })
            }
            col.addView(row, lp(M, W).apply { bottomMargin = dp(14) })
        }
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; setClipChildren(false); clipToPadding = false; setPadding(dp(16), dp(12), dp(16), dp(130)); addView(col) }
    }

    // ================= animasi & overlay =================
    private fun launch(v: View, pkg: String) {
        val i = pm.getLaunchIntentForPackage(pkg) ?: return
        prefs.edit().putInt("c_$pkg", prefs.getInt("c_$pkg", 0) + 1).apply()
        try { startActivity(i, ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()) } catch (e: Exception) { return }
        if (overlay != null) closeOverlay(false)
        content.animate().cancel(); content.animate().scaleX(1.15f).scaleY(1.15f).alpha(0f).setDuration(260).start()
    }
    private fun pop() {
        cells.removeAll { !it.isAttachedToWindow }
        cells.forEachIndexed { i, v ->
            v.animate().cancel(); v.alpha = 0f; v.scaleX = .6f; v.scaleY = .6f; v.translationY = dp(30).toFloat()
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setStartDelay((i % 24) * 14L).setDuration(420).setInterpolator(OvershootInterpolator(1.2f)).start()
        }
    }
    private fun showPill(dotsMode: Boolean) {
        srch.animate().alpha(if (dotsMode) 0f else 1f).setDuration(200).start()
        dots.animate().alpha(if (dotsMode) 1f else 0f).setDuration(200).start()
        val to = if (dotsMode) dp(14 * pages.size + 28) else dp(120); val l = pill.layoutParams
        ValueAnimator.ofInt(l.width, to).apply { duration = 250; addUpdateListener { l.width = it.animatedValue as Int; pill.layoutParams = l } }.start()
    }
    private fun blurTo(on: Boolean) {
        blurAnim?.cancel()
        blurAnim = ValueAnimator.ofFloat(blurLvl, if (on) 1f else 0f).apply {
            duration = 250
            addUpdateListener {
                blurLvl = it.animatedValue as Float
                stage.setRenderEffect(if (blurLvl <= 0.01f) null else RenderEffect.createBlurEffect(28f * blurLvl, 28f * blurLvl, Shader.TileMode.CLAMP))
            }
            start()
        }
        content.animate().scaleX(if (on) 0.96f else 1f).scaleY(if (on) 0.96f else 1f).setDuration(250).start()
    }
    private fun showOverlay(v: View, blur: Boolean = true) {
        val had = overlay != null; val hadBlur = ovBlur
        overlay?.let { root.removeView(it) }
        v.alpha = 0f; root.addView(v, FrameLayout.LayoutParams(M, M)); overlay = v; ovBlur = blur
        v.animate().alpha(1f).setDuration(220).start()
        if (blur && !(had && hadBlur)) blurTo(true) else if (!blur && had && hadBlur) blurTo(false)
    }
    private fun closeOverlay(anim: Boolean = true) {
        val v = overlay ?: return; overlay = null; openFid = null
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0)
        if (anim) v.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(v) }.start() else root.removeView(v)
        if (ovBlur) blurTo(false)
    }

    private fun appItems(pkg: String): List<Act> {
        val l = ArrayList<Act>()
        if (onHome(pkg)) l.add(Triple("Hapus dari Home", false, { removeFromHome(pkg) })) else l.add(Triple("Tambah ke Home", false, { addToHome(pkg) }))
        l.add(Triple("Info App", false, { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }))
        l.add(Triple("Hapus App (permanen)", true, { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }))
        return l
    }

    private fun menu(anchor: View, entry: String, drag: Boolean, items: List<Act>) {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val loc = IntArray(2); anchor.getLocationInWindow(loc)
        ov.addView(ImageView(this).apply { setImageBitmap(anchor.drawToBitmap()) }, FrameLayout.LayoutParams(anchor.width, anchor.height).apply { leftMargin = loc[0]; topMargin = loc[1] })
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isClickable = true; setPadding(0, dp(6), 0, dp(6)) }
        glassOn(p, 18, 90)
        items.forEach { (t, red, f) ->
            p.addView(TextView(this).apply {
                text = t; textSize = 16f; setTextColor(if (red) 0xFFFF3B30.toInt() else fg); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), 0, dp(18), 0); setOnClickListener { closeOverlay(); f() }
            }, lp(M, dp(46)))
        }
        val below = loc[1] < root.height / 2
        val l = FrameLayout.LayoutParams(dp(230), W, if (below) Gravity.TOP else Gravity.BOTTOM).apply {
            leftMargin = (loc[0] + anchor.width / 2 - dp(115)).coerceIn(dp(12), maxOf(dp(12), root.width - dp(242)))
            if (below) topMargin = loc[1] + anchor.height + dp(12) else bottomMargin = root.height - loc[1] + dp(12)
        }
        ov.addView(p, l)
        p.pivotX = dp(115).toFloat(); p.pivotY = if (below) 0f else dp(200).toFloat(); p.scaleX = .6f; p.scaleY = .6f; p.alpha = 0f
        p.animate().scaleX(1f).scaleY(1f).alpha(1f).setInterpolator(OvershootInterpolator(1.1f)).setDuration(260).start()
        showOverlay(ov)
        if (drag) arm(entry, anchor, 1)
    }

    // ================= folder =================
    private fun openFolder(fid: String) {
        val f = folds[fid] ?: return
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(TextView(this).apply {
            text = f.name; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setShadowLayer(6f, 0f, 1f, 0x88000000.toInt())
            setOnClickListener { renameFolder(fid) }
        }, lp(W, W).apply { bottomMargin = dp(12) })
        val g = GridLayout(this).apply { columnCount = 3; setClipChildren(false) }
        f.apps.mapNotNull { byPkg(it) }.forEach { g.addView(cell(it, dp(60), true, fg, fid), GridLayout.LayoutParams().apply { width = dp(92); height = dp(100) }) }
        val panel = FrameLayout(this).apply { setPadding(dp(12), dp(12), dp(12), dp(12)); isClickable = true; setClipChildren(false); addView(g) }
        glassOn(panel, 30, 60)
        col.addView(panel, lp(W, W))
        ov.addView(col, FrameLayout.LayoutParams(W, W, Gravity.CENTER))
        col.scaleX = .5f; col.scaleY = .5f
        col.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(1.0f)).setDuration(300).start()
        showOverlay(ov)
        openFid = fid; folderGrid = g; folderPanel = panel
    }

    // ================= drag & drop =================
    private fun arm(entry: String, v: View, ctx: Int) { armEntry = entry; armView = v; armCtx = ctx; armX = lastX; armY = lastY }
    private fun hitCell(x: Float, y: Float): View? {
        val r = Rect()
        for (c in cells) if (c.isShown && c.getGlobalVisibleRect(r) && r.contains(x.toInt(), y.toInt())) return c
        return null
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) gd.onTouchEvent(ev)
        val x = ev.rawX; val y = ev.rawY
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = x; lastY = y; armEntry = null; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                lastX = x; lastY = y
                if (dragging) { moveDrag(x, y); return true }
                if (armEntry != null && Math.hypot((x - armX).toDouble(), (y - armY).toDouble()) > dp(10)) {
                    startDrag(x, y)
                    val c = MotionEvent.obtain(ev); c.action = MotionEvent.ACTION_CANCEL; super.dispatchTouchEvent(c); c.recycle()
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (dragging) { endDrag(x, y); return true }; armEntry = null }
        }
        return super.dispatchTouchEvent(ev)
    }
    private fun startDrag(x: Float, y: Float) {
        val v = armView ?: return; dragging = true
        dragView = ImageView(this).apply { setImageBitmap(v.drawToBitmap()); scaleX = 1.1f; scaleY = 1.1f; alpha = .92f }
        root.addView(dragView, FrameLayout.LayoutParams(v.width, v.height))
        srcCell = v.parent as? View; srcCell?.alpha = 0f
        if (armCtx == 1 && overlay != null) closeOverlay(false)
        moveDrag(x, y)
    }
    private fun placeAt(x: Float, y: Float): Place? {
        val pl = layoutPlaces.getOrNull(pager.currentItem - 1) ?: return null
        val c = ((x - dp(8)) / cellW).toInt(); val r = ((y - topIns - dp(8)) / cellH).toInt()
        return pl.firstOrNull { r >= it.r && r < it.r + it.sr && c >= it.c && c < it.c + it.sc }
    }
    private fun insertIdx(x: Float, y: Float): Int {
        val hp = pager.currentItem - 1; if (hp < 0 || hp >= pages.size - 2 || y < topIns) return -1
        placeAt(x, y)?.let { return it.idx }
        val pl = layoutPlaces.getOrNull(hp)
        if (pl != null && pl.isNotEmpty()) return pl.last().idx + 1
        var end = 0
        for (i in 0 until hp) layoutPlaces.getOrNull(i)?.lastOrNull()?.let { end = it.idx + 1 }
        return end
    }
    private fun moveDrag(x: Float, y: Float) {
        val dv = dragView ?: return; dv.x = x - dv.width / 2f; dv.y = y - dv.height / 2f
        if (armCtx != 1) return
        val t = placeAt(x, y); val e = armEntry ?: ""
        val fx = ((x - dp(8)) % cellW) / cellW; val fy = ((y - topIns - dp(8)) % cellH) / cellH
        val merge = t != null && t.sc == 1 && t.sr == 1 && t.e != e && !e.startsWith("w:") && !e.startsWith("#") && !t.e.startsWith("w:") && fx in 0.22f..0.78f && fy in 0.05f..0.7f
        val v = if (merge && t != null) homeViews[t.idx] else null
        if (v !== tgtView) {
            tgtView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
            v?.animate()?.scaleX(1.18f)?.scaleY(1.18f)?.setDuration(120)?.start(); tgtView = v
        }
        mergeIdx = if (merge && t != null) t.idx else -1
        val dir = if (x < dp(36)) -1 else if (x > root.width - dp(36)) 1 else 0
        if (dir != edgeDir) { h.removeCallbacks(edgeRun); edgeDir = dir; if (dir != 0) h.postDelayed(edgeRun, 600) }
    }
    private fun endDrag(x: Float, y: Float) {
        dragging = false; h.removeCallbacks(edgeRun); edgeDir = 0
        dragView?.let { root.removeView(it) }; dragView = null
        tgtView?.apply { scaleX = 1f; scaleY = 1f }; tgtView = null; srcCell?.alpha = 1f
        val e = armEntry; armEntry = null
        if (e != null) { if (armCtx == 1) dropHome(e, x, y) else dropFolder(e, x, y) }
        mergeIdx = -1
    }
    private fun dropHome(e: String, x: Float, y: Float) {
        val idx = insertIdx(x, y); if (idx < 0) { rebuildKeep(); return }
        var done = false
        if (mergeIdx >= 0 && mergeIdx < home.size) {
            val t = home[mergeIdx]
            if (t.startsWith("#")) { folds[t.drop(1)]!!.apps.add(e); home.remove(e); done = true }
            else if (!t.startsWith("w:") && t != e) {
                val id = "f" + System.currentTimeMillis(); folds[id] = Fold("Folder", mutableListOf(t, e))
                home[home.indexOf(t)] = "#$id"; home.remove(e); done = true
            }
        }
        if (!done) { val from = home.indexOf(e); home.remove(e); var ins = idx; if (from in 0 until idx) ins--; home.add(ins.coerceIn(0, home.size), e) }
        normalize(); saveLayout(); rebuildKeep()
    }
    private fun dropFolder(e: String, x: Float, y: Float) {
        val fid = openFid ?: return; val f = folds[fid] ?: return
        val r = Rect(); val panel = folderPanel; val g = folderGrid
        if (panel != null && g != null && panel.getGlobalVisibleRect(r) && r.contains(x.toInt(), y.toInt())) {
            val gl = IntArray(2); g.getLocationOnScreen(gl)
            val idx = (((y - gl[1]) / dp(100)).toInt().coerceAtLeast(0) * 3 + ((x - gl[0]) / dp(92)).toInt().coerceIn(0, 2))
            f.apps.remove(e); f.apps.add(idx.coerceAtMost(f.apps.size), e); saveLayout(); closeOverlay(false); rebuildKeep(); openFolder(fid)
        } else {
            f.apps.remove(e); if (home.size < 2 * cap) home.add(e)
            normalize(); saveLayout(); closeOverlay(false); rebuildKeep()
        }
    }

    // ================= menu tekan lama di home, pengaturan =================
    private fun showEditBar() {
        val ov = FrameLayout(this).apply { setBackgroundColor(0x44000000); setOnClickListener { closeOverlay() } }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, botIns + dp(24)) }
        fun item(t: String, ic: Int, f: () -> Unit) = bar.addView(TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; compoundDrawablePadding = dp(6)
            setCompoundDrawablesWithIntrinsicBounds(0, ic, 0, 0); compoundDrawableTintList = ColorStateList.valueOf(Color.WHITE)
            setOnClickListener { closeOverlay(); f() }
        }, lp(0, W, 1f))
        item("Wallpaper", android.R.drawable.ic_menu_gallery) { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 300) }
        item("Widget", android.R.drawable.ic_menu_add) { openWidgetPicker() }
        item("Dock", android.R.drawable.ic_menu_more) { openDockSettings() }
        item("Gaya Ikon", android.R.drawable.ic_menu_edit) { iconStyleDialog() }
        item("Pengaturan", android.R.drawable.ic_menu_preferences) { openSettings() }
        ov.addView(bar, FrameLayout.LayoutParams(M, W, Gravity.BOTTOM))
        showOverlay(ov, false)
    }

    private fun iconStyleDialog() {
        val hasPack = File(filesDir, "iconpack").list()?.isNotEmpty() == true
        val o = arrayOf("Default sistem", "Ikuti tema sistem (monokrom, Android 13+)",
            if (hasPack) "Icon pack yang diimpor" else "Icon pack (belum ada, impor dulu)", "Impor icon pack (.zth / .zip)…")
        AlertDialog.Builder(this).setTitle("Gaya Ikon").setItems(o) { _, i ->
            if (i == 3) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 400)
            else if (i == 2 && !hasPack) toast("Impor dulu file .zth / .zip")
            else { prefs.edit().putInt("style", i).apply(); applyAll(false) }
        }.show()
    }

    private fun importPack(u: Uri) {
        toast("Mengimpor icon pack…")
        Thread {
            var n = 0; var wall = false
            try {
                val dir = File(filesDir, "iconpack"); dir.deleteRecursively(); dir.mkdirs()
                contentResolver.openInputStream(u)?.use { ins ->
                    val z = java.util.zip.ZipInputStream(ins.buffered())
                    var en = z.nextEntry
                    while (en != null) {
                        val nm = en.name.replace('\\', '/'); val low = nm.lowercase()
                        if (!en.isDirectory && low.endsWith(".png")) {
                            val base = nm.substringAfterLast('/')
                            if (low.contains("/icons/") || low.startsWith("icons/")) { File(dir, base).outputStream().use { o -> z.copyTo(o) }; n++ }
                            else if (low.contains("wallpaper/") && !low.contains("lock") && !wall) { File(filesDir, "theme_wall.png").outputStream().use { o -> z.copyTo(o) }; wall = true }
                        }
                        z.closeEntry(); en = z.nextEntry
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread {
                if (n == 0) { toast("Tidak ada ikon di file ini"); return@runOnUiThread }
                packIndex = null; prefs.edit().putInt("style", 2).apply(); applyAll(false); toast("$n ikon diimpor")
                if (wall) AlertDialog.Builder(this).setMessage("Pakai wallpaper dari tema ini juga?").setPositiveButton("Ya") { _, _ ->
                    try {
                        val b = BitmapFactory.decodeFile(File(filesDir, "theme_wall.png").path)
                        File(filesDir, "wall.jpg").outputStream().use { o -> b.compress(Bitmap.CompressFormat.JPEG, 92, o) }; applyAll(true)
                    } catch (_: Exception) {}
                }.setNegativeButton("Tidak", null).show()
            }
        }.start()
    }

    private fun openSettings() {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setTextColor(fg) }
        fun rowText(t: String, v: String, f: () -> Unit) = col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setOnClickListener { f() }
            addView(label(t), lp(0, W, 1f)); addView(TextView(ctx).apply { text = v; setTextColor(0xFF8E8E93.toInt()) })
        }, lp(M, dp(52)))
        fun sw(t: String, key: String, def: Boolean) = col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; addView(label(t), lp(0, W, 1f))
            addView(Switch(ctx).apply { isChecked = prefs.getBoolean(key, def); setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply(); applyAll(false) } })
        }, lp(M, dp(52)))
        fun seek(t: String, key: String, mn: Int, mx: Int, def: Int, wall: Boolean) {
            col.addView(label(t), lp(M, W).apply { topMargin = dp(10) })
            col.addView(SeekBar(this).apply {
                max = mx - mn; progress = prefs.getInt(key, def) - mn
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {}
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) { prefs.edit().putInt(key, (sb?.progress ?: 0) + mn).apply(); applyAll(wall) }
                })
            }, lp(M, W))
        }
        col.addView(TextView(this).apply { text = "Pengaturan Layar Utama"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg) }, lp(M, W).apply { bottomMargin = dp(8) })
        rowText("Kisi Desktop", "${cols}×${rows}") {
            val o = arrayOf("4×5", "4×6", "4×7", "5×6", "5×7")
            AlertDialog.Builder(this).setItems(o) { _, i ->
                val c = o[i][0].digitToInt(); val r = o[i][2].digitToInt(); prefs.edit().putInt("cols", c).putInt("rows", r).apply(); closeOverlay(); applyAll(false)
            }.show()
        }
        rowText("Pengaturan Dock", "›") { closeOverlay(); openDockSettings() }
        rowText("Gaya Ikon", when (prefs.getInt("style", 0)) { 0 -> "Default sistem"; 1 -> "Ikuti tema"; else -> "Icon pack" }) { closeOverlay(); iconStyleDialog() }
        rowText("Impor icon pack", ".zth / .zip") { closeOverlay(); startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 400) }
        sw("Tampilkan teks nama app", "labels", true)
        sw("Sembunyikan dock bawah", "nodock", false)
        seek("Ukuran ikon app (70–140%)", "scale", 70, 140, 100, false)
        seek("Intensitas blur (folder, panel, library)", "blur", 0, 100, 60, true)
        val panel = FrameLayout(this).apply { isClickable = true; addView(ScrollView(ctx).apply { addView(col) }) }
        glassOn(panel, 28, 70)
        ov.addView(panel, FrameLayout.LayoutParams(M, M).apply { setMargins(dp(14), topIns + dp(30), dp(14), botIns + dp(30)) })
        showOverlay(ov)
    }

    /** Panel pengaturan dock: tanpa blur/gelap, dock di bawah kelihatan langsung berubah saat slider digeser. */
    private fun openDockSettings() {
        if (pager.currentItem == 0 || pager.currentItem == pages.size - 1) pager.setCurrentItem(1, false)
        prefs.edit().putBoolean("nodock", false).apply(); applyDock(); dock.alpha = 1f; dock.translationY = 0f
        val ov = FrameLayout(this).apply { setOnClickListener { closeOverlay() } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14)) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setTextColor(fg) }
        fun seek(t: String, key: String, mn: Int, mx: Int, def: Int, live: Boolean, after: () -> Unit) {
            col.addView(label(t), lp(M, W).apply { topMargin = dp(6) })
            col.addView(SeekBar(this).apply {
                max = mx - mn; progress = prefs.getInt(key, def) - mn
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { prefs.edit().putInt(key, p + mn).apply(); if (live) after() } }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) { if (!live) after() }
                })
            }, lp(M, W))
        }
        col.addView(TextView(this).apply { text = "Pengaturan Dock"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg) })
        seek("Bentuk tepi (kotak ↔ bulat)", "dk_r", 0, 48, 30, true) { applyDock() }
        seek("Posisi (turun ↔ naik)", "dk_y", 0, 140, 8, true) { applyDock() }
        seek("Lebar samping (makin besar makin sempit)", "dk_m", 0, 90, 12, true) { applyDock() }
        seek("Tinggi dock", "dk_h", 56, 130, 86, true) { applyDock() }
        seek("Ukuran ikon dock", "dk_i", 36, 76, 58, false) { buildDock() }
        seek("Intensitas blur", "dk_blur", 0, 100, 60, true) { recalcDockBlur(); dock.invalidate() }
        seek("Kecerahan warna dock", "dk_br", 0, 100, if (dark) 55 else 80, true) { applyDock() }
        seek("Ketebalan warna (transparansi)", "dk_a", 20, 230, 120, true) { applyDock() }
        col.addView(TextView(this).apply {
            text = "Selesai"; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(0xFF30D158.toInt()) }
            setOnClickListener { closeOverlay() }
        }, lp(M, dp(44)).apply { topMargin = dp(12) })
        val panel = FrameLayout(this).apply { isClickable = true; addView(ScrollView(ctx).apply { addView(col) }) }
        glassOn(panel, 26, 30)
        ov.addView(panel, FrameLayout.LayoutParams(M, (root.height * 0.58f).toInt(), Gravity.TOP).apply { setMargins(dp(12), topIns + dp(12), dp(12), 0) })
        showOverlay(ov, false)
    }

    // ================= widget picker (daftar widget sistem) =================
    private fun appLabel(p: String) = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }

    private fun openWidgetPicker() {
        val groups = awm.installedProviders.groupBy { it.provider.packageName }.toList().sortedBy { appLabel(it.first).lowercase() }
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim); setOnClickListener { closeOverlay() } }
        val sheet = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isClickable = true; setPadding(dp(18), dp(14), dp(18), 0) }
        glassOn(sheet, 28, 130)
        val title = TextView(this).apply { text = "Tambahkan Widget"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg) }
        val body = FrameLayout(this)
        var detailFn: (String, List<AppWidgetProviderInfo>) -> Unit = { _, _ -> }
        fun showList() {
            title.text = "Tambahkan Widget"; title.setOnClickListener(null); body.removeAllViews()
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            groups.forEach { (pkg, l) ->
                val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
                val ic: View = byPkg(pkg)?.let { iconView(it) } ?: ImageView(this).apply { setImageDrawable(try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }) }
                row.addView(ic, lp(dp(44), dp(44)))
                row.addView(TextView(this).apply { text = appLabel(pkg); textSize = 17f; setTextColor(fg); setPadding(dp(14), 0, 0, 0) }, lp(0, W, 1f))
                row.addView(TextView(this).apply { text = "${l.size}  ›"; setTextColor(0xFF8E8E93.toInt()); textSize = 15f })
                row.setOnClickListener { detailFn(pkg, l) }
                col.addView(row); col.addView(View(this).apply { setBackgroundColor(if (dark) 0x22FFFFFF else 0x22000000) }, lp(M, 1))
            }
            body.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        }
        detailFn = { pkg, l ->
            title.text = "‹  " + appLabel(pkg); title.setOnClickListener { showList() }; body.removeAllViews()
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            l.forEach { info ->
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
                glassOn(card, 20, 20)
                val pd: Drawable? = try { info.loadPreviewImage(ctx, 0) } catch (e: Exception) { null }
                val dr: Drawable? = pd ?: byPkg(pkg)?.let { BitmapDrawable(resources, icon(it)) }
                card.addView(ImageView(this).apply { adjustViewBounds = true; maxHeight = dp(170); setImageDrawable(dr) }, lp(W, W))
                card.addView(TextView(this).apply { text = info.loadLabel(pm); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg); setPadding(0, dp(8), 0, 0) })
                val desc = try { info.loadDescription(ctx)?.toString() } catch (e: Exception) { null }
                if (!desc.isNullOrEmpty()) card.addView(TextView(this).apply { text = desc; textSize = 13f; setTextColor(0xFF8E8E93.toInt()); gravity = Gravity.CENTER })
                val sp = spanInfo(info)
                card.addView(TextView(this).apply { text = "${sp.second}×${sp.first}"; setTextColor(0xFF8E8E93.toInt()); textSize = 13f })
                card.addView(TextView(this).apply {
                    text = "Tambahkan ke Layar Utama"; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(0xFF30D158.toInt()) }
                    setOnClickListener { closeOverlay(); addWidgetFromProvider(info) }
                }, lp(M, dp(44)).apply { topMargin = dp(10) })
                col.addView(card, lp(M, W).apply { bottomMargin = dp(10) })
            }
            body.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        }
        sheet.addView(title, lp(M, W).apply { bottomMargin = dp(10) }); sheet.addView(body, lp(M, 0, 1f))
        ov.addView(sheet, FrameLayout.LayoutParams(M, (root.height * 0.82f).toInt(), Gravity.BOTTOM))
        showList(); showOverlay(ov)
    }

    private fun addWidgetFromProvider(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId(); pendingWid = id
        val ok = try { awm.bindAppWidgetIdIfAllowed(id, info.provider) } catch (e: Exception) { false }
        if (ok) afterBind(id) else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try { startActivityForResult(i, 202) } catch (e: Exception) { toast("Widget tidak bisa dipasang"); host.deleteAppWidgetId(id) }
        }
    }
    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { toast("Widget tidak bisa dipasang"); host.deleteAppWidgetId(id); return }
        if (info.configure != null) { try { host.startAppWidgetConfigureActivityForResult(this, id, 0, 201, null) } catch (e: Exception) { placeWidget(id) } }
        else placeWidget(id)
    }
    private fun placeWidget(id: Int) {
        val e = "w:$id"; val hp = (pager.currentItem - 1).coerceIn(0, maxOf(0, layoutPlaces.size - 1))
        var ins = home.size
        layoutPlaces.getOrNull(hp)?.lastOrNull()?.let { ins = it.idx + 1 }
        val t = ArrayList(home); t.add(ins.coerceAtMost(t.size), e)
        if (paginate(t).size > 2 && paginate(home).size <= 2) { toast("Home penuh, widget tidak muat (2 halaman)"); host.deleteAppWidgetId(id); return }
        home.add(ins.coerceAtMost(home.size), e); saveLayout(); rebuildKeep()
        val pg = paginate(home).indexOfFirst { l -> l.any { it.e == e } }; if (pg >= 0) pager.setCurrentItem(pg + 1, true)
    }

    private fun setPhoto(iv: ImageView, b: Bitmap) {
        iv.setImageBitmap(b)
        val c = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        iv.outlineSpotShadowColor = c; iv.outlineAmbientShadowColor = c
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        when (rc) {
            201 -> if (res == RESULT_OK) placeWidget(pendingWid) else host.deleteAppWidgetId(pendingWid)
            202 -> if (res == RESULT_OK) afterBind(pendingWid) else host.deleteAppWidgetId(pendingWid)
            400 -> if (res == RESULT_OK) d?.data?.let { importPack(it) }
            300 -> {
                val u = d?.data ?: return; if (res != RESULT_OK) return
                try {
                    val b = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE; dec.setTargetSampleSize(maxOf(1, info.size.width / 1600))
                    }
                    File(filesDir, "wall.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    applyAll(true)
                } catch (_: Exception) {}
            }
            in 100..103 -> {
                val u = d?.data ?: return; if (res != RESULT_OK) return
                try {
                    val b = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, u)) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE; dec.setTargetSampleSize(maxOf(1, info.size.width / 1000))
                    }
                    File(filesDir, "p${rc - 100}.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    photos.getOrNull(rc - 100)?.let { setPhoto(it, b) }
                } catch (_: Exception) {}
            }
        }
    }

    // ================= search / library list =================
    private fun openSearch(list: Boolean) {
        val ov = FrameLayout(this).apply { setBackgroundColor(scrim) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), topIns + dp(14), dp(34), botIns + dp(10)) }
        val et = EditText(this).apply {
            background = null; hint = "Search"; setHintTextColor(0x99888888.toInt()); setTextColor(fg); textSize = 17f
            maxLines = 1; inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEARCH; setPadding(dp(8), 0, 0, 0)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), 0)
            addView(SearchIcon(ctx).apply { tint = fg }, lp(dp(18), dp(18))); addView(et, lp(0, M, 1f))
        }
        glassOn(bar, 23, 60)
        val res = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(res); isVerticalScrollBarEnabled = false }
        val secs = LinkedHashMap<Char, View>()
        val idx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val lineCol = if (dark) 0x33FFFFFF else 0x33000000
        fun sec(t: String) = TextView(this).apply { text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg); setPadding(dp(4), dp(12), 0, dp(6)) }
        fun line() = View(this).apply { setBackgroundColor(lineCol) }
        fun row(a: App): View {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
            val iv = iconView(a); r.addView(iv, lp(dp(44), dp(44)))
            r.addView(TextView(this).apply { text = a.label; textSize = 17f; setTextColor(fg); setPadding(dp(14), 0, 0, 0) })
            r.setOnClickListener { launch(r, a.pkg) }
            r.setOnLongClickListener { menu(iv, a.pkg, false, appItems(a.pkg)); true }
            return r
        }
        fun fill(q: String) {
            res.removeAllViews(); idx.removeAllViews(); secs.clear(); val t = q.trim().lowercase()
            if (t.isEmpty() && !list) {
                res.addView(sec("Suggestions"))
                val r = LinearLayout(this).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }; glassOn(r, 26, 40)
                apps.sortedByDescending { prefs.getInt("c_${it.pkg}", 0) }.take(4).forEach { r.addView(cell(it, dp(58), true, fg), lp(0, W, 1f)) }
                res.addView(r)
            }
            val l = if (t.isEmpty()) apps else apps.filter { it.label.lowercase().contains(t) }
            var last = ' '
            l.forEach { a ->
                if (t.isEmpty()) {
                    val ch = a.label.first().uppercaseChar().let { if (it.isLetter()) it else '#' }
                    if (ch != last) {
                        last = ch
                        if (secs.isNotEmpty()) res.addView(line(), lp(M, dp(2)).apply { topMargin = dp(6) })
                        val s2 = sec(ch.toString()); secs[ch] = s2; res.addView(s2)
                    }
                }
                res.addView(row(a)); res.addView(line(), lp(M, 1))
            }
            if (t.isEmpty()) secs.keys.forEach { ch ->
                idx.addView(TextView(this).apply { text = ch.toString(); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg); gravity = Gravity.CENTER }, lp(dp(24), 0, 1f))
            }
        }
        idx.setOnTouchListener { v, e ->
            if (idx.childCount > 0 && (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE)) {
                val i = (e.y / v.height * idx.childCount).toInt().coerceIn(0, idx.childCount - 1)
                secs[secs.keys.elementAt(i)]?.let { sv.scrollTo(0, it.top) }
            }
            true
        }
        et.doAfterTextChanged { fill(it.toString()) }
        if (list) {
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(bar, lp(0, dp(46), 1f))
            top.addView(TextView(this).apply { text = "Cancel"; textSize = 16f; setTextColor(fg); setPadding(dp(14), 0, 0, 0); setOnClickListener { closeOverlay() } })
            col.addView(top, lp(M, W)); col.addView(sv, lp(M, 0, 1f))
        } else { col.addView(sv, lp(M, 0, 1f)); col.addView(bar, lp(M, dp(46)).apply { topMargin = dp(8) }) }
        fill("")
        ov.addView(col, FrameLayout.LayoutParams(M, M)); ov.setOnClickListener { closeOverlay() }
        ov.addView(idx, FrameLayout.LayoutParams(dp(26), M, Gravity.END).apply { topMargin = topIns + dp(if (list) 76 else 20); bottomMargin = botIns + dp(if (list) 20 else 76); rightMargin = dp(4) })
        showOverlay(ov)
        if (!list) { et.requestFocus(); h.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0) }, 250) }
    }
}
